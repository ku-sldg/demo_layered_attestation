1) Build module
make -f /usr/share/selinux/devel/Makefile pipeline.pp

2) Install module
sudo semodule -i pipeline.pp

3) Run
./master.sh

4) Check output
cat d4/out.txt

5) Check for SELinux denials
sudo audit2allow -al

6) Remove module
sudo  semodule -r pipeline
